package com.example.tourcompanion

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ClaudeApiClient(private val apiKey: String) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val mediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun askClaude(prompt: String): String? = withContext(Dispatchers.IO) {
        if (apiKey.isBlank() || apiKey == "YOUR_ANTHROPIC_API_KEY") {
            return@withContext null
        }

        try {
            val jsonBody = JSONObject().apply {
                put("model", "claude-3-5-sonnet-20241022")
                put("max_tokens", 400)
                put("messages", JSONArray().put(
                    JSONObject().apply {
                        put("role", "user")
                        put("content", "You are Semmozhi, a friendly and helpful travel companion assistant. Answer the traveler's question helpfully, concisely, and with empathy: $prompt")
                    }
                ))
            }

            val request = Request.Builder()
                .url("https://api.anthropic.com/v1/messages")
                .addHeader("x-api-key", apiKey)
                .addHeader("anthropic-version", "2023-06-01")
                .addHeader("content-type", "application/json")
                .post(jsonBody.toString().toRequestBody(mediaType))
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext "Claude API Error: ${response.code} - ${response.message}"
                }

                val responseBody = response.body?.string() ?: return@withContext null
                val jsonResponse = JSONObject(responseBody)
                val contentArray = jsonResponse.getJSONArray("content")
                if (contentArray.length() > 0) {
                    val firstContent = contentArray.getJSONObject(0)
                    return@withContext firstContent.getString("text").trim()
                }
                return@withContext null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext "Failed to connect to Claude: ${e.localizedMessage}"
        }
    }
}
