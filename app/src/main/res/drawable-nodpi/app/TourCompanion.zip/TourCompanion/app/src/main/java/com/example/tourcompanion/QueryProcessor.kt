package com.example.tourcompanion

import android.content.Context
import java.util.Locale
import kotlin.math.ln

/**
 * Keyword-based travel tip lookup.
 *
 * Improvements over the first version:
 *  - Tips are loaded from SQLite ONCE and kept in memory (no full table scan per question).
 *  - Multi-word keywords ("lost wallet") and hyphenated ones ("check-in") now match.
 *  - Rare keywords score higher than common ones (e.g. "doctor" beats "find").
 *  - Stop words are ignored completely, and "weak" words count for much less.
 *  - Light stemming: travel / travelling, plan / planning, phrase / phrases.
 *  - Topic words give a small bonus, which breaks ties (ATM question -> "ATM Safety").
 *  - Distress words always return the Emergency tip.
 *
 * Public API is unchanged: processQuery(question): TravelTip?
 *
 * Call warmUp() from a background thread (e.g. SplashActivity) so the first
 * question does not do database work on the main thread.
 */
class QueryProcessor(context: Context) {

    private val appContext = context.applicationContext

    private class IndexedTip(
        val tip: TravelTip,
        val phrases: List<List<String>>,   // each keyword as a list of stemmed tokens
        val topicTokens: List<String>
    )

    private class Index(
        val tips: List<IndexedTip>,
        val weights: Map<List<String>, Double>
    )

    private val index: Index by lazy { buildIndex() }

    /** Forces the database read + indexing. Safe to call from a background thread. */
    fun warmUp() {
        check(index.tips.isNotEmpty()) { "travel_tips table is empty" }
    }

    fun processQuery(question: String): TravelTip? {

        val tokens = tokenize(question)
        if (tokens.isEmpty()) return null

        // Safety first: distress words always return the Emergency tip.
        if (tokens.any { it in URGENT }) {
            index.tips
                .firstOrNull { it.tip.topic == "Emergency" }
                ?.let { return it.tip }
        }

        var best: TravelTip? = null
        var bestScore = 0.0

        for (item in index.tips) {

            var score = 0.0

            for (phrase in item.phrases) {
                if (containsPhrase(tokens, phrase)) {
                    score += index.weights[phrase] ?: 0.0
                }
            }

            // Small bonus when the question mentions the tip's topic name.
            for (topicToken in item.topicTokens) {
                if (topicToken in tokens) score += TOPIC_BONUS
            }

            if (score > bestScore) {
                bestScore = score
                best = item.tip
            }
        }

        return if (bestScore >= MIN_SCORE) best else null
    }

    // ---------------------------------------------------------
    // Index building
    // ---------------------------------------------------------

    private fun buildIndex(): Index {

        val tips = loadTips()

        val indexedTips = tips.map { tip ->
            IndexedTip(
                tip = tip,
                phrases = tip.keywords
                    .map { tokenize(it) }
                    .filter { it.isNotEmpty() }
                    .distinct(),
                topicTokens = tokenize(tip.topic)
            )
        }

        // How many tips use each keyword phrase?
        val docFreq = HashMap<List<String>, Int>()
        for (item in indexedTips) {
            for (phrase in item.phrases) {
                docFreq[phrase] = (docFreq[phrase] ?: 0) + 1
            }
        }

        val total = indexedTips.size.toDouble()

        val weights = docFreq.mapValues { (phrase, df) ->
            var w = ln(total / df) + 1.0          // rarer keyword -> higher weight
            if (phrase.size > 1) w *= phrase.size // phrases are more specific
            if (phrase.size == 1 && phrase[0] in WEAK) w *= 0.3
            w
        }

        return Index(indexedTips, weights)
    }

    private fun loadTips(): List<TravelTip> {

        val helper = TravelDatabaseHelper(appContext)
        val result = ArrayList<TravelTip>()

        try {
            helper.readableDatabase
                .rawQuery(
                    "SELECT topic, keywords, answer FROM travel_tips ORDER BY id",
                    null
                )
                .use { cursor ->
                    while (cursor.moveToNext()) {
                        result += TravelTip(
                            topic = cursor.getString(0),
                            keywords = cursor.getString(1)
                                .split(",")
                                .map { it.trim().lowercase(Locale.ROOT) }
                                .filter { it.isNotEmpty() },
                            answer = cursor.getString(2)
                        )
                    }
                }
        } finally {
            helper.close()
        }

        return result
    }

    // ---------------------------------------------------------
    // Text helpers
    // ---------------------------------------------------------

    private fun containsPhrase(tokens: List<String>, phrase: List<String>): Boolean {

        if (phrase.size == 1) return phrase[0] in tokens
        if (phrase.size > tokens.size) return false

        for (i in 0..tokens.size - phrase.size) {
            if (tokens.subList(i, i + phrase.size) == phrase) return true
        }
        return false
    }

    private companion object {

        const val MIN_SCORE = 1.0
        const val TOPIC_BONUS = 1.0

        val NON_ALNUM = Regex("[^a-z0-9\\s]")
        val SPACES = Regex("\\s+")

        val SUFFIXES = listOf("ing", "ed", "es", "s", "e")

        val STOP_WORDS = setOf(
            "where", "what", "how", "can", "is", "the", "a", "an", "i", "me",
            "my", "do", "should", "tell", "please", "to", "of", "in", "for",
            "on", "at", "are", "there", "this", "that", "it", "and", "or",
            "with", "be", "need", "want", "about", "near", "any", "some",
            "get", "go", "from", "you", "your", "we", "us", "have", "has",
            "will", "would", "could", "which", "when", "who", "why", "does",
            "did", "am", "was", "were", "been", "so", "if", "not", "no"
        )

        // Words that appear in many tips but say little about the topic.
        val WEAK = listOf(
            "help", "find", "place", "safe", "person",
            "public", "plan", "visit", "travel", "trip"
        ).map { stem(it) }.toSet()

        // Distress words -> always show the Emergency tip. Tune this list.
        val URGENT = listOf(
            "attack", "attacked", "assault", "assaulted", "kidnap", "kidnapped",
            "harass", "harassed", "harassment", "threat", "threatened",
            "accident", "injured", "bleeding", "unconscious", "stalked", "stalking"
        ).map { stem(it) }.toSet()

        fun tokenize(text: String): List<String> =
            text.lowercase(Locale.ROOT)
                .replace(NON_ALNUM, " ")
                .split(SPACES)
                .filter { it.isNotEmpty() && it !in STOP_WORDS }
                .map { stem(it) }

        /** Very light stemmer: applied to both keywords and questions, so they stay consistent. */
        fun stem(word: String): String {

            if (word.length <= 3 || word.all { it.isDigit() }) return word

            for (suffix in SUFFIXES) {
                if (word.endsWith(suffix) && word.length - suffix.length >= 3) {

                    var base = word.dropLast(suffix.length)

                    // travell -> travel, plann -> plan
                    if (base.length > 3 && base[base.length - 1] == base[base.length - 2]) {
                        base = base.dropLast(1)
                    }
                    return base
                }
            }
            return word
        }
    }
}
